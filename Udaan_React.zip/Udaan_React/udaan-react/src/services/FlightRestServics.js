
export default class FlightRestService {
    constructor() {
        this.flight = null;
        this.url = "http://localhost:8880";
    }

    async getFlights() {
        return await fetch(this.url + "/flights").then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).then(data =>{
            return data;
        }).catch(error => {
            console.log(error.message);
        });
    }

    async getFlightByCode(code) {
        return await fetch(this.url + "/flight/" + code).then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).then(data =>{
            return data;
        }).catch(error => {
            console.log(error.message);
        });
    }

    async saveFlight(flight) {
        return await fetch(this.url + "/add", {
            method:"POST",
            mode:"cors",
            headers: {
                "content-type":"application/json"
            },
            body:JSON.stringify(flight)
        }).then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).catch(error => {
            console.log(error.message);
        });
    }

    async updateFlight(flight) {
        return await fetch(this.url + "/update", {
            method:"PUT",
            mode:"cors",
            headers: {
                "content-type":"application/json"
            },
            body:JSON.stringify(flight)
        }).then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).catch(error => {
            console.log(error.message);
        });
    }

    async deleteFlight(code) {
        return await fetch(this.url + "/del/" + code, {
            method:"DELETE",
            mode:"cors"
        }).then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).catch(error => {
            console.log(error.message);
        });
    }

    handleResponseError(response) {
        throw new Error("Http error, Status: "+response.status);
    }
}