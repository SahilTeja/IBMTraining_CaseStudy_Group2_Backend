import logo from './logo.svg';
import './App.css';
import ListFlights from './components/ListFlights';

function App() {
  return (
    <div className="App">
      <ListFlights />
    </div>
  );
}

export default App;
