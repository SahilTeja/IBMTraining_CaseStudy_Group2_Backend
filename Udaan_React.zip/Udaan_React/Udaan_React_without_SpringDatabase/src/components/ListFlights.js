import { Component } from "react";
import FlightDetails from './FlightDetails';
import AddFlight from './AddFlight';
import FlightService from '../services/FlightService';
import EditFlight from "./EditFlight";

export default class ListFlights extends Component{
    constructor(props) {
        super(props);
        this.service = new FlightService();

        this.state = {
            flights:'',
            selectedFlight:'',
            showDetails:false,
            newFlight:false,
            editFlight:false
        }
    }

    getFlights() {
        const planes = this.service.getFlights();
            this.setState({flights:planes});
    }

    componentDidMount() {
        this.getFlights();
    }
    //To initialise the list first when the ListFlights component is called .
    //This is just like init of angular.
    //This will run first after constructor .

    onSelection = (code) =>{
        const plane = this.service.getFlightByCode(code);
            this.setState({
                selectedFlight:plane,
                showDetails:true,
                // editFlight:false,
                // newFlight:false
            });
    }

    onNewFlight = () => {
        this.clearState();
        this.setState({
            newFlight:true
        });
    }

    render() {
        if(!this.state.flights)
            return null;

        const list = this.state.flights.map((x) =>
            <li key={x.code} onClick={() => this.onSelection(x.code)} class="list-group-item">{x.code}</li>
        );

        return(
            <div class="jumbotron">
                <h1>List of Flights</h1>
                <ul class="list-group">
                    {list}
                </ul>
                <button class="btn btn-success" onClick={() => this.onNewFlight()}>Add New Flight</button>
                <hr />
                {   
                    this.state.showDetails && this.state.selectedFlight &&
                    <FlightDetails flight={this.state.selectedFlight} onEdit={this.onEditFlight} onDelete={this.onDeleteFlight}/>
                }
                {
                    this.state.newFlight && 
                    <AddFlight onSubmit = {this.onSaveFlight} onReset={this.onCancelFlight}/>
                }
                {
                    this.state.editFlight && this.state.selectedFlight &&
                    <EditFlight flight={this.state.selectedFlight} onSubmit={this.onUpdateFlight} onReset={this.onCancelFlight}/>
                }
            </div>
        );
    }

    onDeleteFlight = (code) => {
        this.clearState();
        this.service.deleteFlight(code);
        this.getFlights();
    }
    onUpdateFlight = (flight) => {
        this.clearState();
        this.service.updateFlight(flight);
        this.getFlights();
    }

    onSaveFlight = (flight) => {
        this.clearState();
        this.service.saveFlight(flight);
        this.getFlights();
    }

    onCancelFlight = () => {
        this.clearState();
    }
    clearState = () => {
        this.setState({
            showDetails:false,
            editFlight:false,
            newFlight:false,
            selectedFlight:''
        });
    }

    onEditFlight= () => {
        this.setState({
            showDetails:false,
            editFlight:true,
            newFlight:false
        });
    }
}