package com.udaan.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.udaan.entity.Flight;
import com.udaan.service.FlightService;

@RestController
@CrossOrigin("*")
public class FlightController {
	
	@Autowired
	private FlightService service;
	// http:localhost:8880
	@PostMapping(value="/add",consumes ="application/json")
	public void addFlight(@RequestBody Flight flight) {
		service.addFlight(flight);
	}
	
	@GetMapping(value="/flight/{code}",produces="application/json")
	public Flight getFlight(@PathVariable("code") int code) {
		
		return service.getByCode(code);
	}

	@GetMapping(value="/flights",produces="application/json")
	public List<Flight> getAllFlight() {
		
		return service.getAllFlight();
	}

	@GetMapping(value="/flights/{carrier}",produces="application/json")
	public List<Flight> getByCarrier(@PathVariable("carrier") String carrier) {
		
		return service.getByCarrier(carrier);
	}
	

	@GetMapping(value="/flights/{source}/{destination}",produces="application/json")
	public List<Flight> getByRoute(@PathVariable("source") String source,@PathVariable("destination") String destination) {
		
		return service.getByRoute(source, destination);
	}
	
	@DeleteMapping(value="/del/{code}")
	public void deleteFlight(@PathVariable("code") int code) {
		service.removeFlight(code);
	}
	
	@PutMapping(value="/update")
	public boolean updateFlight(@RequestBody Flight flight) {
		return service.updateFlight(flight);

	}
	
	
	
	
	

}
