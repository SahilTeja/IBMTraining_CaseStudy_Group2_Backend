/**
 * 
 * @author Harsh Anand
 *
 */
export class AdminLoginModel {                
    public userName : string = '';
    public password : string = '';
}