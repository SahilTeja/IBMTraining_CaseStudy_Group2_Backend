/**
 * 
 * @author Harsh Anand
 *
 */
export class AddUserModel {               
    public password : string = '';
    public name : string = '';
    public email : string = '';
    public aadhar : string = '';
    public panCard : string = '';
    public salary : number = 0;
    public mobilenumber : string = '';
    public aadress : string = '';
    public state : string = '';
    public country : string = "India";
    
}