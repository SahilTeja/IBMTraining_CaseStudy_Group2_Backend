/**
 * 
 * @author Harsh Anand
 *
 */
export class LoanStatus {                
    public status : number = 5;
}