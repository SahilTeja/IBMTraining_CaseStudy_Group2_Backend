/**
 * 
 * @author Harsh Anand
 *
 */
export class UserLoginModel {    
    public userId : number = 0;            
    public email : string = '';
    public password : string = '';
}